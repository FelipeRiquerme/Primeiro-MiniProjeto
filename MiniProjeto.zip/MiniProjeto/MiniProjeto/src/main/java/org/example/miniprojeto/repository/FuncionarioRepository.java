package org.example.miniprojeto.repository;

import org.example.miniprojeto.model.Funcionario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FuncionarioRepository extends JpaRepository<Funcionario, Long> {
    @Query("SELECT f FROM Funcionario f WHERE f.salario > :valor")
    List<Funcionario> filtrarSalario(@Param("valor") double valor);

    Boolean existsByEmail (String email);
}