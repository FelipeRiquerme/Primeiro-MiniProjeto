package org.example.miniprojeto.model;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Funcionario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Prencha o nome do funcionário")
    private String nome;

    @NotBlank(message = "Prencha o cargo do funcionário")
    private String cargo;

    @Positive(message = "O salário precisa ser maior que zero!")
    @NotNull(message = "Prencha o salário do funcionário")
    private Double salario;

    @NotBlank(message = "Prencha o email do funcionário")
    @Email(message =  "Email inválido")
    //@Column(unique = true)
    private String email;
}
