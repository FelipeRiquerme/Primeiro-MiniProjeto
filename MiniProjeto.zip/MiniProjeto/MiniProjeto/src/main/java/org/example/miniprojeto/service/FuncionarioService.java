package org.example.miniprojeto.service;

import org.example.miniprojeto.model.Funcionario;
import org.example.miniprojeto.repository.FuncionarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Service
public class FuncionarioService {
    private final FuncionarioRepository repository;

    public FuncionarioService(FuncionarioRepository repository){
        this.repository = repository;
    }
    public Funcionario salvar(Funcionario funcionario){
        if(repository.existsByEmail(funcionario.getEmail())){
            throw new RuntimeException("Email já existente");
        }
        return repository.save(funcionario);
    }

    public Funcionario buscar(Long id){
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Funcionário não encontrado!"));

    }
    public List<Funcionario> listar(){
        return repository.findAll();
    }
    public void deletar(Long id){
        repository.deleteById(id);
    }

    public List<Funcionario> filtrarSalario(Double salario){
        return repository.filtrarSalario(salario);
    }

}
