package org.example.miniprojeto.controller;


import jakarta.validation.Valid;
import org.example.miniprojeto.model.Funcionario;
import org.example.miniprojeto.service.FuncionarioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Funcionarios")
public class Funcionariocontroller {

    private final FuncionarioService service;

    public Funcionariocontroller(FuncionarioService service){
        this.service = service;
    }

    @GetMapping
    public List<Funcionario> listar(){
        return service.listar();
    }

    @PostMapping
    public Funcionario criar(@RequestBody @Valid Funcionario funcionario){
        return service.salvar(funcionario);
    }

    @GetMapping("/{id}")
    public Funcionario buscar(@PathVariable Long id){
        return service.buscar(id);
    }

    @PutMapping("/{id}")
    public Funcionario atualizar(@PathVariable Long id, @RequestBody @Valid Funcionario funcionario){
        funcionario.setId(id);
        return service.salvar(funcionario);


    }
    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id){
        service.deletar(id);
    }
}
